#!/bin/sh
clear
echo "Warning! this script is not responsible for any mishaps while setting up"
echo ""
echo ""
echo "" 
echo ""
read -p "Do you want to update and upgrade your system? (y or n)  : " upd_upg
echo ""
if [ $upd_upg = y ]
	then
	sudo apt-get update -y
	sudo apt-get upgrade -y
	echo ""
	read -p "Do you want to restart your system? [recommended = y] (y or n)  : " reset
	echo ""
	if [ $reset = y ]
		then
		exit
	fi
fi
read -p "Do you want to install all packages? [recommended = y] (y or n)  : " pkg_inst
echo ""
read -p "Do you want to create a info page for php? [recommended = y] (y or n)  : " php_info
echo ""
read -p "Do you want to delete index.html? [recommended = y] (y or n)  : " del_html
echo ""
read -p "Do you want to install MariaDB? [recommended = n] (y or n)  : " mar_db
echo ""
read -p "What is your ubuntu username for the account you are using? : " usr_nm
echo ""
read -p "what do you want your username to be for mysql?  : " mysql_usr_nm
echo ""
read -p "What do you want your password to be for mysql? : " mysql_passwd
echo ""
if [ $pkg_inst = y ]
	then 
		echo "All querys are accepted"
		echo ""
		read -p "Do you want to continue? (y or n)  : " ctn1
		if [ $ctn1 = y ]
			then
			echo ""
			echo "This script has multiple packages, this may take a while."
			sleep 2
			sudo apt-get install apache2 -y
			sudo apt-get install apache2-utils -y
			sudo systemctl enable apache2
			sudo systemctl start apache2
			echo "apache = done"
			echo ""
			echo ""
			sudo apt-get install php7.4 -y
			sudo apt-get install php7.4-mysql -y
			sudo apt-get install libapache2-mod-php7.4 -y
			sudo apt-get install php7.4-cli -y
			sudo apt-get install php7.4-cgi -y
			sudo apt-get install php7.4-gd -y
			sudo apt-get install php-pear -y
			echo "php = done"
			echo ""
			echo ""
			sudo apt-get install curl
			echo "curl = done"
			echo ""
			echo ""
			sudo apt-get install mysql-server -y 
			sudo apt-get install mysql-client -y
			echo "mysql = done"
			echo ""
			echo "Please fill out the following form to make a secure mysql installation, you can look p online for help"
			wait 5
			sudo mysql_secure_installation 
			echo "Installation secured. continuing..."
			wait 1
			echo ""
			echo ""
			if [ $mar_db = y ]
				then
				sudo apt-get install mariadb-server -y 
				sudo apt-get install mariadb-client -y
				echo "mariadb = done"
				echo ""
				echo ""
			fi
			sudo apt-get install git -y
			echo "git = done"
			echo ""
			echo ""
			sudo apt-get update -y
			echo "update = done"
			echo ""
			echo ""
			if [ $php_info = y ]
				then
				sudo mkdir /var/www/html/php_info
sudo echo "<?php 
phpinfo();
?>" > /var/www/html/php_info/index.php
				echo "Go to localhost/php_info in you browser!"
				echo ""
				echo ""
			fi
			if [ $del_html = y ]
				then
				sudo rm /var/www/html/index.html
				echo ""
				echo ""
			fi
			echo "Packages installed"
			echo "Downloading wget package"
			sleep 2
			sudo wget -c http://wordpress.org/latest.tar.gz
			echo "Wordpress_download = done"
			sudo tar -xzvf /home/$usr_nm/latest.tar.gz
			echo "Wordpress_install = done"
			echo ""
			echo ""
			sleep 2
			echo "Changing ownership"
			sudo chown -R www-data:www-data /var/www/html/
			sudo chmod -R 755 /var/www/html/
			echo ""
			echo ""
			echo "configuring ip addresses"
			sudo systemctl start mysql
			sudo service mysql start
			sleep 3
echo "bind-address            = 127.0.0.1                 
bind-address            = 0.0.0.0" > /etc/mysql/mysql.conf.d/mysqld.cnf
			sudo service mysql restart
			sudo systemctl restart mysql
			echo ""
			echo ""
			sleep 2
			echo "Moving files"
			sudo rsync -av wordpress/* /var/www/html/
			echo ""
			echo ""
			echo "Starting services"
			sudo systemctl start mysql
			sudo service mysql start
			sudo systemctl enable mysql
			sudo service mysql enable
			sudo systemctl start apache2
			sudo service apache2 start
			sudo systemctl enable apache2
			sudo service apache2 enable
			echo ""
			echo ""
			echo "{!Important} For the next part, put in each command following this message EXACTLY.):"
			echo "CREATE DATABASE wp_website;"
			echo "CREATE USER '$mysql_usr_nm'@'localhost' IDENTIFIED BY '$mysql_passwd';"
			echo "GRANT ALL PRIVILEGES ON wp_website.* TO '*username'@'localhost';"
			echo "FLUSH PRIVILEGES;"
			echo "EXIT;"
			echo ""
			sleep 2
			sudo mysql -u root -p
			echo "Database created"
			echo ""
			echo ""
			echo "Auto config wordpress"
			sudo rm /var/www/html/wp-config-sample.php
echo "// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wp-website'); /** MySQL database username */ define('DB_USER', '$mysql_usr_nm'); /** MySQL database password */ define('DB_PASSWORD', '$mysql_passwd'); /** MySQL hostname */ define('DB_HOST', 'localhost')" > /var/www/html/wp-config.php
			echo ""
			echo ""
			echo "Restarting apache"
			sudo systemctl restart apache2.service
			sudo service apache2 restart
			sleep 1
			echo ""
			echo ""
			echo "Restarting mysql"
			sudo systemctl restart mysql.service 
			sudo service mysql restart
			echo ""
			echo ""
			echo "Updating all packages"
			sudo apt-get update
			sudo apt-get upgrade
			echo ""
			echo ""
			echo "Finished! go to your_ip_address/wp-admin or localhost/wp-admin to finish setting up!"
			echo ""
			echo "Thank you for using Ubuntu 20.04 wordpress Auto install"
			exit
		fi
	else 
		echo "you must install all packages! please restart the script"
		exit
fi
