To use the auto installer, either chmod or make the .sh script executable the type the file location in the terminal.
example:
sudo chmod +x /home/(user)/ubuntu_20.04_wordpress_autoinstall/ubuntu_20.04_wordpress_autoinstall.sh
sudo /home/(user)/ubuntu_20.04_wordpress_autoinstall/ubuntu_20.04_wordpress_autoinstall.sh

Then you are good to go!
